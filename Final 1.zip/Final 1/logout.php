<?php 
    // Start a session or resume the current session
	session_start();

	// Clear all session variables
	$_SESSION = array();

	// Check if a session cookie is set and delete it
	if (isset($_COOKIE[session_name()])) {
		setcookie(session_name(), '', time()-86400, '/');
	}

	// Destroy the session
	session_destroy();

	// Redirect to the login page with the action parameter set to logout
	header('Location: login.php?action=logout');
?>
