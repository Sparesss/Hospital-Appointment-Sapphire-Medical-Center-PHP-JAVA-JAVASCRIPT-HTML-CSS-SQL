<?php
    // Include the file with database connection details
    include("../connection.php");

    // Check if the form data is submitted using the POST method
    if($_POST){

        // Get all user data from the 'webuser' table
        $result= $database->query("select * from webuser");

        // Retrieve form data
        $name=$_POST['name'];
        $nic=$_POST['nic'];
        $oldemail=$_POST["oldemail"];
        $address=$_POST['address'];
        $email=$_POST['email'];
        $tele=$_POST['Tele'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        $id=$_POST['id00'];

        // Check if the entered password matches the confirmed password
        if ($password==$cpassword){
            $error='3';

            // Check if the email already exists in the 'patient' table
            $sqlmain= "select patient.pid from patient inner join webuser on patient.pemail=webuser.email where webuser.email=?;";
            $stmt = $database->prepare($sqlmain);
            $stmt->bind_param("s",$email);
            $stmt->execute();
            $result = $stmt->get_result();

            // If the email exists, get the corresponding patient ID, otherwise use the provided ID
            if($result->num_rows==1){
                $id2=$result->fetch_assoc()["pid"];
            }else{
                $id2=$id;
            }

            // If the provided ID does not match the retrieved ID, set an error
            if($id2!=$id){
                $error='1';
            }else{
                // Update patient information in the 'patient' table
                $sql1="update patient set pemail='$email',pname='$name',ppassword='$password',pnic='$nic',ptel='$tele',paddress='$address' where pid=$id ;";
                $database->query($sql1);
                
                // Update email in the 'webuser' table
                $sql1="update webuser set email='$email' where email='$oldemail' ;";
                $database->query($sql1);

                // Set success error code
                $error= '4';
            }
            
        }else{
            // Set password mismatch error code
            $error='2';
        }
    }else{
        // Set default error code
        $error='3';
    }

    // Redirect to the settings page with the appropriate error code and user ID
    header("location: settings.php?action=edit&error=".$error."&id=".$id);
?>
