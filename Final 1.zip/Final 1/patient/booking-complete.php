<?php
    // Start the session
    session_start();

    // Check if the 'user' session variable is set
    if(isset($_SESSION["user"])){
        // Check if the 'user' session variable is empty or if the 'usertype' is not 'p' (patient)
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
            // Redirect to the login page if not logged in as a patient
            header("location: ../login.php");
        }else{
            // Retrieve the user's email from the session
            $useremail=$_SESSION["user"];
        }

    }else{
        // Redirect to the login page if the session variable is not set
        header("location: ../login.php");
    }
    
    // Include the file containing the database connection details
    include("../connection.php");

    // Prepare SQL statement to retrieve patient information using a parameterized query
    $sqlmain= "select * from patient where pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s",$useremail);
    $stmt->execute();

    // Get the result of the query and fetch the patient's information
    $userrow = $stmt->get_result();
    $userfetch=$userrow->fetch_assoc();
    $userid= $userfetch["pid"];
    $username=$userfetch["pname"];

    // Check if the form has been submitted using the POST method
    if($_POST){
        // Check if the 'booknow' button is set in the POST data
        if(isset($_POST["booknow"])){
            // Retrieve form data
            $apponum=$_POST["apponum"];
            $scheduleid=$_POST["scheduleid"];
            $date=$_POST["date"];
            $scheduleid=$_POST["scheduleid"];

            // SQL query to insert a new appointment into the 'appointment' table
            $sql2="insert into appointment(pid,apponum,scheduleid,appodate) values ($userid,$apponum,$scheduleid,'$date')";
            
            // Execute the SQL query
            $result= $database->query($sql2);

            // Redirect to the appointment page with success information
            header("location: appointment.php?action=booking-added&id=".$apponum."&titleget=none");
        }
    }
?>
