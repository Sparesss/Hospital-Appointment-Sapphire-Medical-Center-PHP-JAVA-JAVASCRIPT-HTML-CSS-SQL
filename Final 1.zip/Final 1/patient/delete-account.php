<?php
    // Start the session
    session_start();

    // Check if the 'user' session variable is set
    if(isset($_SESSION["user"])){
        // Check if the 'user' session variable is empty or if the 'usertype' is not 'p' (patient)
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
            // Redirect to the login page if not logged in as a patient
            header("location: ../login.php");
        }else{
            // Retrieve the user's email from the session
            $useremail=$_SESSION["user"];
        }

    }else{
        // Redirect to the login page if the session variable is not set
        header("location: ../login.php");
    }

    // Include the file containing the database connection details
    include("../connection.php");

    // Prepare SQL statement to retrieve patient information using a parameterized query
    $sqlmain= "select * from patient where pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s",$useremail);
    $stmt->execute();

    // Get the result of the query and fetch the patient's information
    $userrow = $stmt->get_result();
    $userfetch=$userrow->fetch_assoc();
    $userid= $userfetch["pid"];
    $username=$userfetch["pname"];

    // Check if the request is made using the GET method
    if($_GET){
        // Include the database connection file again
        include("../connection.php");

        // Get the 'id' parameter from the GET request
        $id=$_GET["id"];

        // Retrieve the email associated with the patient using a parameterized query
        $sqlmain= "select * from patient where pid=?";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $result001 = $stmt->get_result();
        $email=($result001->fetch_assoc())["pemail"];

        // Delete the user from the 'webuser' table based on the retrieved email
        $sqlmain= "delete from webuser where email=?;";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Delete the patient from the 'patient' table based on the retrieved email
        $sqlmain= "delete from patient where pemail=?";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Redirect to the logout page after successfully deleting the patient
        header("location: ../logout.php");
    }
?>
