<?php
    // Start the session
    session_start();

    // Check if the 'user' session variable is set and if the user is an admin
    if(isset($_SESSION["user"])){
        // Check if the 'user' session variable is empty or if the 'usertype' is not 'a' (admin)
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // Redirect to the login page if not logged in as an admin
            header("location: ../login.php");
        }

    }else{
        // Redirect to the login page if the session variable is not set
        header("location: ../login.php");
    }

    // Check if the request is made using the GET method
    if($_GET){

        // Include the file with database connection details
        include("../connection.php");

        // Get the 'id' parameter from the GET request
        $id=$_GET["id"];

        // Delete the appointment from the 'appointment' table based on the 'appoid'
        $sql= $database->query("delete from appointment where appoid='$id';");

        // Prepare and execute a statement to delete based on the 'id' using a parameterized query (Note: This part seems incorrect as $sqlmain is not defined)
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("i",$id);
        $stmt->execute();

        // Redirect to the appointment page after deletion
        header("location: appointment.php");
    }
?>
