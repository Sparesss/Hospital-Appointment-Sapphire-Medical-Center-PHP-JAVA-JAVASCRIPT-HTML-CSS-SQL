<?php
    // Create a new instance of the MySQLi class to establish a database connection
    $database = new mysqli("localhost", "root", "", "Health_Center_System");

    // Check if the database connection is successful
    if ($database->connect_error) {
        // If connection fails, terminate the script and display an error message
        die("Connection failed: " . $database->connect_error);
    }
?>
