<?php
    // Start a session to manage user data across pages
    session_start();

    // Check if the user is logged in as an administrator
    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // If not logged in or not an administrator, redirect to the login page
            header("location: ../login.php");
        }
    }else{
        // If the session user variable is not set, redirect to the login page
        header("location: ../login.php");
    }
    
    // Check if there is a GET request
    if($_GET){
        // Include the file containing the database connection details
        include("../connection.php");
        
        // Retrieve the 'id' parameter from the GET request
        $id=$_GET["id"];
    
        // Execute a SQL query to delete the appointment with the specified 'appoid'
        $sql= $database->query("delete from appointment where appoid='$id';");
      
        // Redirect to the 'appointment.php' page after deleting the appointment
        header("location: appointment.php");
    }
?>
