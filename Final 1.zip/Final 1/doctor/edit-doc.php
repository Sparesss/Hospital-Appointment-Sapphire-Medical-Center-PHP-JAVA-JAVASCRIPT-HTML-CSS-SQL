<?php
    // Include the file containing the database connection details
    include("../connection.php");

    // Check if the form has been submitted using the POST method
    if($_POST){

        // Retrieve all records from the 'webuser' table
        $result= $database->query("select * from webuser");

        // Retrieve form data using POST method
        $name=$_POST['name'];
        $oldemail=$_POST["oldemail"];
        $nic=$_POST['nic'];
        $spec=$_POST['spec'];
        $email=$_POST['email'];
        $tele=$_POST['Tele'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        $id=$_POST['id00'];

        // Check if the entered password matches the confirmed password
        if ($password==$cpassword){
            $error='3';

            // Check if a record with the entered email already exists in the 'doctor' table
            $result= $database->query("select doctor.docid from doctor inner join webuser on doctor.docemail=webuser.email where webuser.email='$email';");

            if($result->num_rows==1){
                // If a record exists, retrieve the 'docid'
                $id2=$result->fetch_assoc()["docid"];
            }else{
                // If no record exists, set 'id2' to the current 'id'
                $id2=$id;
            }

            // Display 'id2' (for debugging purposes)
            echo $id2."jdfjdfdh";

            // Check if 'id2' is different from the current 'id'
            if($id2!=$id){
                // If different, set an error indicating duplicate email
                $error='1';

            }else{

                // Update the 'doctor' table with the new data
                $sql1="update doctor set docemail='$email',docname='$name',docpassword='$password',docnic='$nic',doctel='$tele',specialties=$spec where docid=$id ;";
                $database->query($sql1);

                // Update the 'webuser' table with the new email
                $sql1="update webuser set email='$email' where email='$oldemail' ;";
                $database->query($sql1);

                // Display the SQL query (for debugging purposes)
                echo $sql1;

                // Set an error indicating successful update
                $error= '4';

            }

        }else{
            // If passwords do not match, set an error
            $error='2';
        }

    }else{
        // If the form has not been submitted, set an error
        $error='3';
    }

    // Redirect to the 'settings.php' page with error information and the current 'id'
    header("location: settings.php?action=edit&error=".$error."&id=".$id);
?>
