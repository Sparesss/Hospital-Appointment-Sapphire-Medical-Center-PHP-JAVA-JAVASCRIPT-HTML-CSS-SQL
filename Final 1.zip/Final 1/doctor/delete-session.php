<?php
    // Start a session to manage user authentication
    session_start();

    // Check if a user is logged in and has the 'admin' user type
    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // Redirect to the login page if the user is not logged in or is not an admin
            header("location: ../login.php");
        }
    } else {
        // Redirect to the login page if the user is not logged in
        header("location: ../login.php");
    }
    
    // Check if there is a GET request
    if($_GET){
        // Include the file containing the database connection details
        include("../connection.php");
        
        // Get the 'id' parameter from the GET request
        $id=$_GET["id"];
        
        // Delete the schedule record with the specified 'scheduleid' from the 'schedule' table
        $sql= $database->query("delete from schedule where scheduleid='$id';");
      
        // Redirect to the 'schedule.php' page after the deletion
        header("location: schedule.php");
    }
?>
