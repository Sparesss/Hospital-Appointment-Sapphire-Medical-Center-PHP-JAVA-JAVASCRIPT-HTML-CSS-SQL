<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Doctor</title>

    <!-- Inline Style -->
    <style>
        .popup {
            animation: transitionIn-Y-bottom 0.5s;
        }
    </style>
</head>
<body>
    <?php
        // Start or resume the session
        session_start();

        // Check if the "user" session variable is set
        if(isset($_SESSION["user"])){
            // Check if the "user" session variable is empty or if the user type is not 'a' (admin)
            if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
                // Redirect to the login page if the conditions are not met
                header("location: ../login.php");
            }
        } else {
            // Redirect to the login page if the "user" session variable is not set
            header("location: ../login.php");
        }

        // Include the file that establishes the database connection
        include("../connection.php");

        // Check if the form has been submitted using POST
        if($_POST){
            // Retrieve data from the form
            $result= $database->query("select * from webuser");
            $name=$_POST['name'];
            $nic=$_POST['nic'];
            $spec=$_POST['spec'];
            $email=$_POST['email'];
            $tele=$_POST['Tele'];
            $password=$_POST['password'];
            $cpassword=$_POST['cpassword'];
            
            // Check if the entered password matches the confirmed password
            if ($password == $cpassword){
                $error='3';
                $result= $database->query("select * from webuser where email='$email';");
                if($result->num_rows==1){
                    $error='1'; // Email already exists
                } else {
                    // Insert data into the "doctor" and "webuser" tables
                    $sql1 = "insert into doctor(docemail,docname,docpassword,docnic,doctel,specialties) values('$email','$name','$password','$nic','$tele',$spec);";
                    $sql2 = "insert into webuser values('$email','d')";
                    $database->query($sql1);
                    $database->query($sql2);

                    $error = '4'; // Doctor added successfully
                }
            } else {
                $error = '2'; // Passwords do not match
            }
        } else {
            $error = '3'; // Form not submitted
        }

        // Redirect to the "doctors.php" page with the appropriate action and error parameters
        header("location: doctors.php?action=add&error=".$error);
    ?>
</body>
</html>
