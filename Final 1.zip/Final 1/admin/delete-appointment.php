<?php

    // Start a new or resume an existing session
    session_start();

    // Check if the "user" session variable is set
    if(isset($_SESSION["user"])){
        // Check if the "user" session variable is empty or if the user type is not 'a' (assuming 'a' represents admin)
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // Redirect to the login page if the conditions are not met
            header("location: ../login.php");
        }
    }else{
        // Redirect to the login page if the "user" session variable is not set
        header("location: ../login.php");
    }

    // Check if the request contains GET parameters
    if($_GET){

        // Include the file that establishes the database connection
        include("../connection.php");

        // Get the "id" parameter from the GET request
        $id=$_GET["id"];

        // Execute a SQL query to delete a record from the "appointment" table where "appoid" matches the given "id"
        $sql= $database->query("delete from appointment where appoid='$id';");

        // Redirect to the "appointment.php" page after deleting the record
        header("location: appointment.php");
    }

?>
