<?php

    // Start a new or resume an existing session
    session_start();

    // Check if the "user" session variable is set
    if(isset($_SESSION["user"])){
        // Check if the "user" session variable is empty or if the user type is not 'a' (assuming 'a' represents admin)
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // Redirect to the login page if the conditions are not met
            header("location: ../login.php");
        }
    }else{
        // Redirect to the login page if the "user" session variable is not set
        header("location: ../login.php");
    }

    // Check if the request contains GET parameters
    if($_GET){

        // Include the file that establishes the database connection
        include("../connection.php");

        // Get the "id" parameter from the GET request
        $id=$_GET["id"];

        // Execute a SQL query to select all columns from the "doctor" table where "docid" matches the given "id"
        $result001= $database->query("select * from doctor where docid=$id;");

        // Fetch the result as an associative array and retrieve the "docemail" column value
        $email=($result001->fetch_assoc())["docemail"];

        // Execute a SQL query to delete a record from the "webuser" table where "email" matches the retrieved "docemail"
        $sql= $database->query("delete from webuser where email='$email';");

        // Execute a SQL query to delete a record from the "doctor" table where "docemail" matches the retrieved "docemail"
        $sql= $database->query("delete from doctor where docemail='$email';");

        // Redirect to the "doctors.php" page after deleting the records
        header("location: doctors.php");
    }

?>
