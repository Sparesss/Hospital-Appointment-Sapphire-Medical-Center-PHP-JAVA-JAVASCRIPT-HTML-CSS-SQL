<?php
    // Include the file containing the database connection details
    include("../connection.php");

    // Check if there is a POST request
    if($_POST){
        // Retrieve all records from the 'webuser' table
        $result= $database->query("select * from webuser");

        // Retrieve data from the POST request
        $name=$_POST['name'];
        $nic=$_POST['nic'];
        $oldemail=$_POST["oldemail"];
        $spec=$_POST['spec'];
        $email=$_POST['email'];
        $tele=$_POST['Tele'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        $id=$_POST['id00'];
        
        // Check if the entered password matches the confirmed password
        if ($password==$cpassword){
            $error='3';

            // Check if there is an existing record with the same email in the 'doctor' table
            $result= $database->query("select doctor.docid from doctor inner join webuser on doctor.docemail=webuser.email where webuser.email='$email';");

            if($result->num_rows==1){
                // If an existing record is found, retrieve the corresponding 'docid'
                $id2=$result->fetch_assoc()["docid"];
            }else{
                // If no existing record is found, set 'id2' to the provided 'id'
                $id2=$id;
            }
            
            // Display the value of 'id2' for testing purposes
            echo $id2."jdfjdfdh";

            // Check if 'id2' is different from the provided 'id', indicating a duplicate email
            if($id2!=$id){
                $error='1';
            }else{
                // If no duplicate email, update the 'doctor' and 'webuser' tables with new data
                $sql1="update doctor set docemail='$email',docname='$name',docpassword='$password',docnic='$nic',doctel='$tele',specialties=$spec where docid=$id ;";
                $database->query($sql1);
                
                $sql1="update webuser set email='$email' where email='$oldemail' ;";
                $database->query($sql1);

                $error= '4';
            }
            
        }else{
            // If passwords do not match, set 'error' to 2
            $error='2';
        }
    }else{
        // If there is no POST request, set 'error' to 3
        $error='3';
    }

    // Redirect to the 'doctors.php' page with additional parameters in the URL
    header("location: doctors.php?action=edit&error=".$error."&id=".$id);
?>
