<?php
    // Start or resume the session
    session_start();

    // Check if the "user" session variable is set
    if(isset($_SESSION["user"])){
        // Check if the "user" session variable is empty or if the user type is not 'a' (admin)
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // Redirect to the login page if the conditions are not met
            header("location: ../login.php");
        }
    } else {
        // Redirect to the login page if the "user" session variable is not set
        header("location: ../login.php");
    }

    // Check if the form has been submitted using POST
    if($_POST){
        // Include the file that establishes the database connection
        include("../connection.php");

        // Retrieve data from the form
        $title = $_POST["title"];
        $docid = $_POST["docid"];
        $nop = $_POST["nop"];
        $date = $_POST["date"];
        $time = $_POST["time"];

        // SQL query to insert a new session into the "schedule" table
        $sql = "insert into schedule (docid, title, scheduledate, scheduletime, nop) values ($docid, '$title', '$date', '$time', $nop);";
        
        // Execute the SQL query
        $result = $database->query($sql);

        // Redirect to the "schedule.php" page with action and title parameters in the URL
        header("location: schedule.php?action=session-added&title=$title");
    }
?>
