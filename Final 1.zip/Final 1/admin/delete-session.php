<?php
    // Start or resume a session
    session_start();

    // Check if the 'user' session variable is set and has a non-empty value, and if the 'usertype' is 'a' (admin)
    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            // Redirect to the login page if the user is not authenticated or is not an admin
            header("location: ../login.php");
        }
    }else{
        // Redirect to the login page if there is no active session
        header("location: ../login.php");
    }
    
    
    // Check if there is a GET request
    if($_GET){
        // Include the file containing the database connection details
        include("../connection.php");
        
        // Get the 'id' parameter from the GET request
        $id=$_GET["id"];
       
        // Execute a SQL query to delete a record from the 'schedule' table where 'scheduleid' matches the provided 'id'
        $sql= $database->query("delete from schedule where scheduleid='$id';");
        
        // Redirect the user to the 'schedule.php' page after deleting the record
        header("location: schedule.php");
    }
?>
